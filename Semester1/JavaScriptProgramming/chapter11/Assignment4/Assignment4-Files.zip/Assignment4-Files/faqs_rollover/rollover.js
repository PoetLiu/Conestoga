$(document).ready(() => {

}); // end ready