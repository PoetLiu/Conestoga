$(document).ready(() => {
    $("#accordion").accordion();
});