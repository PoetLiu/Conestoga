package com.peng.lab1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class checkout_form extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkout_form);
    }
}